#ifndef INTERFACE_H
#define	INTERFACE_H

void interface();


#endif	/* INTERFACE_H */

