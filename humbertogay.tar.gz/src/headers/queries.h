#ifndef QUERIES_H
#define	QUERIES_H

int _02_codigo_produtos_letra();
int _03_compras_e_fact_mensal_prod();
int _03_compras_e_fact_mensal_prod_old();
int _04_prods_nao_comprados();
int _05_tabela_cliente();
int _06_codigos_clientes_letra();
int _07_compras_intervalo_meses();
int _08_clientes_compraram_prod();
int _09_produtos_mais_comprados_cliente_mes();
int _10_clientes_regulares();
int _11_compras_CSV();
int _12_prods_mais_vendidos();
int _13_tres_prods_mais_comprados();
int _14_clientes_prods_fantasma();

#endif	/* QUERIES_H */

