#ifndef LEITURA_FICHEIROS_H
#define	LEITURA_FICHEIROS_H

int leitura_ficheiros(int, char **);

#endif	/* LEITURA_FICHEIROS_H */

