#ifndef COMPRA_H
#define	COMPRA_H

typedef struct compra* COMPRA;

typedef char * cod_cliente_t;
typedef double preco_unit_t;
typedef int quantidade_t;
typedef char promo_t;
typedef char * cod_produto_t;
typedef int mes_t;

COMPRA inicializa_compra(void);
COMPRA inicializa_compra_completo(cod_cliente_t, cod_produto_t, preco_unit_t, quantidade_t, promo_t, mes_t);
void actualiza_compra(COMPRA, cod_cliente_t, cod_produto_t, preco_unit_t, quantidade_t, promo_t, mes_t);
void free_compra(COMPRA);


/*Get's*/
cod_cliente_t get_cod_cliente(COMPRA);
preco_unit_t get_preco_unit(COMPRA);
quantidade_t get_quantidade(COMPRA);
promo_t get_promo(COMPRA);
cod_produto_t get_cod_produto(COMPRA);
mes_t get_mes(COMPRA);

/* Set's*/
void set_cod_cliente(COMPRA, cod_cliente_t);
void set_preco_unit(COMPRA, preco_unit_t);
void set_quantidade(COMPRA, quantidade_t);
void set_promo(COMPRA,promo_t);
void set_cod_produto(COMPRA,cod_produto_t);
void set_mes(COMPRA, mes_t);



#endif	/* COMPRA_H */

